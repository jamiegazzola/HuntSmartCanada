import collections,gzip,hashlib,io,json,pathlib,sys,zipfile
import shapefile
from pyproj import Transformer
from shapely.geometry import shape,mapping
from shapely.ops import transform
from shapely.geometry.polygon import orient
from shapely.geometry import MultiPolygon
from shapely.validation import explain_validity
source=pathlib.Path(sys.argv[1]); dest=pathlib.Path(sys.argv[2]);dest.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
source_hash=sha(source.read_bytes())
assert source_hash=='6ca7deff332624ee9355d75d18337784fd738b26a16898e3670db1b72ad722d9'
tr=Transformer.from_crs(3005,4326,always_xy=True)
config={'caribou':('caribou',None),'elk':('elk',None),'moose':('moose',None),'mtn_goat':('mountain_goat',None),'mule_deer':('mule_deer',None),'shp_cal_bghn':('wild_sheep','California bighorn'),'shp_dall':('wild_sheep','Dall’s sheep'),'shp_rcky_mtn':('wild_sheep','Rocky Mountain bighorn'),'shp_stone':('wild_sheep','Stone’s sheep'),'wht_tld_deer':('white_tailed_deer',None)}
labels={'few':'L','moderate':'M','plentiful':'H'};codes={'few':1,'moderate':2,'plentiful':3}
features=collections.defaultdict(list); excluded=collections.Counter();audit={};max_area_error=0
with zipfile.ZipFile(source) as z:
 for name,(key,subspecies) in config.items():
  r=shapefile.Reader(shp=io.BytesIO(z.read(name+'.shp')),shx=io.BytesIO(z.read(name+'.shx')),dbf=io.BytesIO(z.read(name+'.dbf')))
  counts=collections.Counter()
  for sr in r.iterShapeRecords():
   p=sr.record.as_dict(); t=p['TYPE'].strip().lower(); target=key; sub=subspecies
   if name=='elk':
    assert p['SPECIES'] in ('rocky mtn.','Roosevelt')
    target='elk' if p['SPECIES']=='rocky mtn.' else 'roosevelt_elk';sub='Rocky Mountain elk' if target=='elk' else 'Roosevelt elk'
   if t not in labels:counts['excluded_'+(t or 'unknown')]+=1;continue
   code=next((p[k] for k in ('REL_ABN','DIST___REL','REL_ABNDCE') if k in p),None)
   if code is not None and code!=codes[t]:counts['excluded_conflicting_code']+=1;continue
   g=shape(sr.shape.__geo_interface__); assert g.is_valid,explain_validity(g)
   err=abs(g.area/p['AREA']-1);max_area_error=max(max_area_error,err);assert err<0.00001
   w=transform(tr.transform,g);assert w.is_valid,explain_validity(w);x1,y1,x2,y2=w.bounds;assert -140<x1<x2<-113 and 48<y1<y2<61
   w=orient(w,sign=1.0) if w.geom_type=='Polygon' else MultiPolygon([orient(v,sign=1.0) for v in w.geoms]);
   # Retain all original vertices; precision limited to about 0.1 m, with validity check.
   def round_coords(v):return [round(x,6) for x in v] if isinstance(v[0],(float,int)) else [round_coords(x) for x in v]
   geometry={'type':w.geom_type,'coordinates':round_coords(mapping(w)['coordinates'])}
   if not shape(geometry).is_valid:geometry=mapping(w)
   assert shape(geometry).is_valid
   prop={'historical_class':labels[t],'abundance':t,'source_record':f'{name}:{sr.record.oid}','area_km2':round(g.area/1e6,3)}
   if sub:prop['subspecies']=sub
   features[target].append({'type':'Feature','geometry':geometry,'properties':prop});counts['included']+=1
  audit[name]={'input':len(r),'counts':dict(counts),'sha256':{ext:sha(z.read(name+'.'+ext)) for ext in ('shp','shx','dbf')}}
manifest={'source_archive_sha256':source_hash,'source':'BC government ungulate distribution map collection; March 2005 compilation; original observation dates unspecified','source_url':'https://www.env.gov.bc.ca/esd/distdata/ecosystems/frpa/Ungulate_Data_and_Maps/','crs':'Inferred NAD83 / BC Albers (EPSG:3005), transformed to WGS84; no PRJ in input. Provincial boundary and area checks passed.','max_relative_area_difference':max_area_error,'input_audit':audit,'layers':{}}
for key,items in features.items():
 payload={'type':'FeatureCollection','compilation_year':2005,'source':manifest['source_url'],'source_archive_sha256':source_hash,'features':items}
 b=json.dumps(payload,separators=(',',':'),ensure_ascii=False).encode();fn=key+'.geojson.gz';(dest/fn).write_bytes(gzip.compress(b,compresslevel=9,mtime=0));manifest['layers'][key]={'features':len(items),'classes':dict(collections.Counter(f['properties']['abundance'] for f in items)),'sha256':sha(b),'compressed_sha256':sha((dest/fn).read_bytes())}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False));print(json.dumps(manifest['layers'],indent=2));print('total',sum(x['features'] for x in manifest['layers'].values()),'bytes',sum(p.stat().st_size for p in dest.glob('*') if p.is_file()))
